#pragma once

enum {
PMOD_G1_A = 0,
PMOD_G1_B = 4,
PMOD_G2_A = 1,
PMOD_G2_B = 5,
PMOD_G3_A = 7,
PMOD_G3_B = 3,
PMOD_G4_A = 6,
PMOD_G4_B = 2,
};
