#pragma once

void yield(void);
