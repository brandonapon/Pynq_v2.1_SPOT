#pragma once

void pyprintf(const char* format, ...);
