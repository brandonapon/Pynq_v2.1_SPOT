#ifndef __ARDUINO_RANGEFINDER_H__
#define __ARDUINO_RANGEFINDER_H__

char on[1] = {1};
char off[1] = {0};

void readByte(char* byte);
char* readRF();


#endif
